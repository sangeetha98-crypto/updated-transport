package com.example.demo.controller;



//import java.text.SimpleDateFormat;
//import java.util.Date;
//import java.util.List;
//import java.util.Properties;
//
//import javax.websocket.Session;
//import java.io.FileOutputStream;
//import java.io.IOException;
//import java.text.ParseException;
//import java.text.SimpleDateFormat;
//import java.util.Date;
import java.util.List;
//import java.util.Properties;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Customer;
import com.example.demo.entity.Transport;
import com.example.demo.model.CustomerService;
import com.example.demo.model.TransportService;

import oracle.jdbc.driver.Message;

@RestController
@CrossOrigin(origins = {"http://localhost:4200", "*"})
public class TransportController {
 @Autowired
	private TransportService ts;
 @Autowired
  CustomerService cs;
  
// @PostMapping("/")
// public Transport addTransport(@RequestBody Transport transport) 
// {
//	 return ts.create(transport);
// }
// 
 @PostMapping("/transport")
 public Transport addTransport(@RequestParam("transportId")String transportId,@RequestParam("customerId")String customerId,@RequestParam("vehicleType")String vehicleType,@RequestParam("driverName")String driverName,@RequestParam("driverPhoneNo")String driverPhoneNo )
 {
	 Customer customer = cs.read(customerId);
	 Transport transport= new Transport();
	 transport.setTransportId(transportId);
	 transport.setCustomer(customer);
	 transport.setVehicleType(vehicleType);
	 transport.setDriverName(driverName);
	 transport.setDriverPhoneNo(driverPhoneNo);
	 return ts.create(transport);
 }
 
 
 
 @GetMapping("/transport")
 public List<Transport> getAllTransport()
 {
	 return ts.read();
 }
 @GetMapping("/transport/{transportId}")
 public Transport findTransportById(@PathVariable("transportId") String transportId)
 {
 
return ts.read(transportId) ;
 }
 
// @PostMapping("/user/otp")
//	public String generatedriverPhoneNo(@RequestBody String emailAddress)
//	{
//		double x=Math.random()*1000000;
//		int otp=(int)x;
//		sendEmail(emailAddress, "This is the driver phone number "+driverPhoneNo+" Do not share the mobileno with anybody");
//		return ""+driverPhoneNo;
//	}
// 
 
 
 
  @PutMapping("/transport/{transportId}")
 public Transport modifyTransport(@RequestBody Transport transport) 
 {
	 return ts.update(transport);
	 
 }
  @DeleteMapping("/transport/{transportId}")
  
		  public void  removeTransport(@PathVariable("transportId") String transportId)
		  {
               ts.delete(transportId);
		  }
}



//private void sendEmail(String to, String message)
//{
//	 Properties props = new Properties();
//        props.put("mail.smtp.host", "true");
//        props.put("mail.smtp.starttls.enable", "true");
//        props.put("mail.smtp.host", "smtp.gmail.com");
//        props.put("mail.smtp.port", "587");
//        props.put("mail.smtp.auth", "true");
//        //Establishing a session with required user details
//        Session session = Session.getInstance(props, new javax.mail.Authenticator() {
//            protected PasswordAuthentication getPasswordAuthentication() {
//                return new PasswordAuthentication("emailsending03@gmail.com", "Team3@jr");
//            }
//        });
//        try {
//            //Creating a Message object to set the email content
//            MimeMessage msg = new MimeMessage(session);
//            //Storing the comma seperated values to email addresses
////            String to = "rjagadeeswaran@yahoo.com";
//            /*Parsing the String with defualt delimiter as a comma by marking the boolean as true and storing the email
//            addresses in an array of InternetAddress objects*/
//            InternetAddress[] address = InternetAddress.parse(to, true);
//            //Setting the recepients from the address variable
//            msg.setRecipients(Message.RecipientType.TO, address);
//            String timeStamp = new SimpleDateFormat("yyyymmdd_hh-mm-ss").format(new Date());
//            msg.setSubject("Otp : " + timeStamp);
//            msg.setSentDate(new Date());
//            msg.setText(message);
//            msg.setHeader("XPriority", "1");
//           
//            Transport.send(msg);
//            System.out.println("MobileNo has been sent successfully");
//        } catch (MessagingException mex) {
//            System.out.println("Unable to send an email:\n" + mex);
//        }
//}
//}
