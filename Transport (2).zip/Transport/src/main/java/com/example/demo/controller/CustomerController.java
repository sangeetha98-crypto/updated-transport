package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Customer;
import com.example.demo.model.CustomerService;

@RestController
@RequestMapping("/customer")
@CrossOrigin(origins = {"http://localhost:4200", "*"})
public class CustomerController 
{
	@Autowired
     CustomerService cs;
	
	@GetMapping("/")
	public List<Customer> getAllCustomer()
	{
		List<Customer> cust =cs.read();
		return cust;	
	}
	@GetMapping("/{customerId}")
	public Customer findCustomerById(@PathVariable("customerId") String customerId)
	{
		return cs.read(customerId);
	}
	@PostMapping("/")
	public Customer addCustomer(@RequestBody Customer cust)
	{
		return cs.create(cust);
	}
	@PutMapping("/")
	public Customer modifyBranch(@RequestBody Customer cust)
	{
		return cs.update(cust);
	}
	
	@DeleteMapping("/{customerId}")
	public void deleteCustomer(@PathVariable("customerId") String customerId)
	{
		cs.delete(customerId);
	}
}
