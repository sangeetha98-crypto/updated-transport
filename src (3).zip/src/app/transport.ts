import { Customer } from "./customer";

export class Transport {
    transportId:string="";
    customer:Customer=new Customer();
      vehicleType:string="";
    driverName:string="";
    driverPhoneNo:string="";
    
}
