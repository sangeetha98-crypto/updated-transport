import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class TransportService {

  url:string='http://localhost:8080/transport/';
  constructor(private http:HttpClient) { }
  
getAllTransports()
{
  return this.http.get(this.url);
}
 findTransportById(transportId:string)
 {
   return this.http.get(this.url+transportId);
 }
  addTransport(transport:any)
  {
    return this.http.post(this.url,transport);

  }
  modifyTransport(transport:any)
  {
    return this.http.put(this.url,transport);
  }
  deleteTransport(transportId:string)
  {
    return this.http.delete(this.url+transportId);
  }
}

